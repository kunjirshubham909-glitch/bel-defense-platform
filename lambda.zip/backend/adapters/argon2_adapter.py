"""
Argon2id Password Hasher Adapter implementing IPasswordHasher.

Modern memory-hard key derivation with PBKDF2-HMAC-SHA256 fallback
for environments without argon2-cffi (which requires Rust).
"""

import hashlib
import hmac
import os
import secrets
from typing import Any

from backend.ports.outbound import IPasswordHasher


class Argon2Adapter(IPasswordHasher):
    """
    Argon2id password hashing with PBKDF2-HMAC-SHA256 fallback.
    
    Argon2id parameters (OWASP 2024 recommended):
    - time_cost: 3 (iterations)
    - memory_cost: 65536 KB (64 MB)
    - parallelism: 4
    - hash_len: 32 bytes
    - type: Argon2id (hybrid of Argon2i and Argon2d)
    
    PBKDF2 fallback: 600,000 iterations (OWASP 2024)
    Format: pbkdf2_sha256$600000$<salt_hex>$<hash_hex>
    """

    # Argon2id parameters
    ARGON2_TIME_COST = 3
    ARGON2_MEMORY_COST = 65536  # KB
    ARGON2_PARALLELISM = 4
    ARGON2_HASH_LEN = 32
    
    # PBKDF2 fallback parameters
    PBKDF2_ITERATIONS = 600000
    PBKDF2_HASH_LEN = 32
    PBKDF2_SALT_LEN = 16
    
    PHC_IDENTIFIER = "pbkdf2_sha256"

    def __init__(self):
        self._argon2 = None
        self._argon2_type = None
        try:
            import argon2
            self._argon2 = argon2
            self._argon2_type = argon2.Type.ID  # Argon2id
        except ImportError:
            pass  # Fallback to PBKDF2

    def hash(self, password: str) -> str:
        """Hash a password using Argon2id or PBKDF2 fallback."""
        if self._argon2:
            return self._hash_argon2(password)
        return self._hash_pbkdf2(password)

    def verify(self, password: str, hashed: str) -> bool:
        """Verify a password against its hash."""
        if not hashed:
            return False
        
        # Check if it's Argon2 hash (starts with $argon2)
        if hashed.startswith("$argon2"):
            if self._argon2:
                return self._verify_argon2(password, hashed)
            # If argon2 not available but hash is argon2, can't verify
            return False
        
        # Check if it's our PBKDF2 format
        if hashed.startswith(f"{self.PHC_IDENTIFIER}$"):
            return self._verify_pbkdf2(password, hashed)
        
        # Unknown format
        return False

    # ──────────────────────────────────────────────────────────────
    # Argon2id Implementation
    # ──────────────────────────────────────────────────────────────

    def _hash_argon2(self, password: str) -> str:
        """Hash using argon2-cffi."""
        hasher = self._argon2.PasswordHasher(
            time_cost=self.ARGON2_TIME_COST,
            memory_cost=self.ARGON2_MEMORY_COST,
            parallelism=self.ARGON2_PARALLELISM,
            hash_len=self.ARGON2_HASH_LEN,
            type=self._argon2_type,
        )
        return hasher.hash(password)

    def _verify_argon2(self, password: str, hashed: str) -> bool:
        """Verify using argon2-cffi."""
        hasher = self._argon2.PasswordHasher(
            time_cost=self.ARGON2_TIME_COST,
            memory_cost=self.ARGON2_MEMORY_COST,
            parallelism=self.ARGON2_PARALLELISM,
            hash_len=self.ARGON2_HASH_LEN,
            type=self._argon2_type,
        )
        try:
            hasher.verify(hashed, password)
            return True
        except self._argon2.exceptions.VerifyMismatchError:
            return False
        except Exception:
            return False

    # ──────────────────────────────────────────────────────────────
    # PBKDF2-HMAC-SHA256 Fallback (OWASP 2024: 600,000 iterations)
    # ──────────────────────────────────────────────────────────────

    def _hash_pbkdf2(self, password: str) -> str:
        """
        Hash using PBKDF2-HMAC-SHA256.
        
        Format: pbkdf2_sha256$600000$<salt_hex>$<hash_hex>
        """
        salt = secrets.token_bytes(self.PBKDF2_SALT_LEN)
        hash_bytes = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt,
            self.PBKDF2_ITERATIONS,
            dklen=self.PBKDF2_HASH_LEN,
        )
        salt_hex = salt.hex()
        hash_hex = hash_bytes.hex()
        return f"{self.PHC_IDENTIFIER}${self.PBKDF2_ITERATIONS}${salt_hex}${hash_hex}"

    def _verify_pbkdf2(self, password: str, hashed: str) -> bool:
        """
        Verify PBKDF2 hash.
        
        Parses: pbkdf2_sha256$iterations$salt_hex$hash_hex
        """
        try:
            parts = hashed.split("$")
            if len(parts) != 4:
                return False
            
            identifier, iterations_str, salt_hex, expected_hash_hex = parts
            
            if identifier != self.PHC_IDENTIFIER:
                return False
            
            iterations = int(iterations_str)
            salt = bytes.fromhex(salt_hex)
            expected_hash = bytes.fromhex(expected_hash_hex)
            
            # Recompute hash
            computed_hash = hashlib.pbkdf2_hmac(
                "sha256",
                password.encode("utf-8"),
                salt,
                iterations,
                dklen=len(expected_hash),
            )
            
            # Constant-time comparison
            return hmac.compare_digest(computed_hash, expected_hash)
        
        except Exception:
            return False