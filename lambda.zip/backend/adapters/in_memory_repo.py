"""
100% offline thread-safe mock adapters for local-first testing.

Implements all outbound ports using in-memory data structures.
No AWS dependencies - pure Python with thread safety for concurrent test scenarios.
"""

import threading
from typing import Any
from copy import deepcopy

from backend.domain.entities import User, DefenseAsset, AuditRecord, AssetState
from backend.ports.outbound import IUserRepository, IAssetRepository, IAuditLedger


class ConcurrencyError(Exception):
    """Raised when optimistic locking fails (expected_state mismatch)."""
    pass


class InMemoryUserRepository(IUserRepository):
    """Thread-safe in-memory user repository with secondary index on cognitoUsername."""

    def __init__(self):
        self._users: dict[str, User] = {}
        self._cognito_index: dict[str, str] = {}  # cognitoUsername -> userId
        self._lock = threading.RLock()

    def save(self, user: User) -> None:
        with self._lock:
            if user.userId in self._users:
                raise ValueError(f"User with userId {user.userId} already exists")
            if user.cognitoUsername in self._cognito_index:
                raise ValueError(f"User with cognitoUsername {user.cognitoUsername} already exists")
            self._users[user.userId] = user
            self._cognito_index[user.cognitoUsername] = user.userId

    def find_by_id(self, user_id: str) -> User | None:
        with self._lock:
            return self._users.get(user_id)

    def find_by_cognito_username(self, cognito_username: str) -> User | None:
        with self._lock:
            user_id = self._cognito_index.get(cognito_username)
            if user_id:
                return self._users.get(user_id)
            return None

    def list_all(self) -> list[User]:
        with self._lock:
            return list(self._users.values())


class InMemoryAssetRepository(IAssetRepository):
    """Thread-safe in-memory asset repository with optimistic locking simulation."""

    def __init__(self):
        self._assets: dict[str, DefenseAsset] = {}
        self._custodian_index: dict[str, set[str]] = {}  # custodianId -> set of assetIds
        self._lock = threading.RLock()

    def save(self, asset: DefenseAsset) -> None:
        with self._lock:
            if asset.assetId in self._assets:
                raise ValueError(f"Asset with assetId {asset.assetId} already exists")
            self._assets[asset.assetId] = deepcopy(asset)
            self._custodian_index.setdefault(asset.custodianId, set()).add(asset.assetId)

    def find_by_id(self, asset_id: str) -> DefenseAsset | None:
        with self._lock:
            return self._assets.get(asset_id)

    def find_by_custodian(self, custodian_id: str) -> list[DefenseAsset]:
        with self._lock:
            asset_ids = self._custodian_index.get(custodian_id, set())
            return [self._assets[aid] for aid in asset_ids if aid in self._assets]

    def update(self, asset: DefenseAsset, expected_state: AssetState | None = None) -> None:
        with self._lock:
            existing = self._assets.get(asset.assetId)
            if not existing:
                raise ValueError(f"Asset {asset.assetId} not found")

            # Optimistic locking: validate expected_state matches current state
            if expected_state is not None and existing.state != expected_state:
                raise ConcurrencyError(
                    f"State mismatch: expected {expected_state.value}, found {existing.state.value}"
                )

            # Update custodian index if custodian changed
            if existing.custodianId != asset.custodianId:
                self._custodian_index[existing.custodianId].discard(asset.assetId)
                self._custodian_index.setdefault(asset.custodianId, set()).add(asset.assetId)

            self._assets[asset.assetId] = deepcopy(asset)

    def list_all(self) -> list[DefenseAsset]:
        with self._lock:
            return list(self._assets.values())


class InMemoryAuditLedger(IAuditLedger):
    """Thread-safe in-memory audit ledger with ordered storage and eventId index."""

    def __init__(self):
        self._records: list[AuditRecord] = []
        self._event_index: dict[str, AuditRecord] = {}
        self._resource_index: dict[tuple[str, str], list[AuditRecord]] = {}
        self._lock = threading.RLock()

    def append(self, record: AuditRecord) -> None:
        with self._lock:
            self._records.append(record)
            self._event_index[record.eventId] = record
            key = (record.resourceType, record.resourceId)
            self._resource_index.setdefault(key, []).append(record)

    def get_last(self) -> AuditRecord | None:
        with self._lock:
            return self._records[-1] if self._records else None

    def get_all(self) -> list[AuditRecord]:
        with self._lock:
            return list(self._records)

    def find_by_event_id(self, event_id: str) -> AuditRecord | None:
        with self._lock:
            return self._event_index.get(event_id)

    def find_by_resource(self, resource_type: str, resource_id: str) -> list[AuditRecord]:
        with self._lock:
            key = (resource_type, resource_id)
            return list(self._resource_index.get(key, []))