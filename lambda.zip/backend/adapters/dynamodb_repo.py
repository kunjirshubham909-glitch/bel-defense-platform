"""
DynamoDB Adapters implementing outbound repository ports.

Production-ready adapters using boto3 with:
- Query on GSI (never scan on hot paths)
- ConditionExpression for optimistic locking
- Proper error handling for ConditionalCheckFailedException
- Connection reuse via module-level boto3 resources
"""

import os
import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError
from typing import Any, Optional, List

from backend.domain.entities import User, DefenseAsset, AuditRecord, ClearanceLevel, MilitaryUnit, AssetState, UserRole
from backend.ports.outbound import IUserRepository, IAssetRepository, IAuditLedger
from backend.adapters.in_memory_repo import ConcurrencyError


# Module-level connection reuse (Lambda execution environment reuse)
_dynamodb_resource = None
_users_table = None
_assets_table = None
_audit_table = None


def _get_dynamodb_resource():
    """Get or create DynamoDB resource (cached for Lambda warm starts)."""
    global _dynamodb_resource
    if _dynamodb_resource is None:
        _dynamodb_resource = boto3.resource(
            'dynamodb',
            region_name=os.getenv('AWS_REGION', 'us-east-1')
        )
    return _dynamodb_resource


def _get_users_table():
    """Get Users table (cached)."""
    global _users_table
    if _users_table is None:
        table_name = os.getenv('USERS_TABLE', 'SIH-Users')
        _users_table = _get_dynamodb_resource().Table(table_name)
    return _users_table


def _get_assets_table():
    """Get Assets table (cached)."""
    global _assets_table
    if _assets_table is None:
        table_name = os.getenv('ASSETS_TABLE', 'SIH-Assets')
        _assets_table = _get_dynamodb_resource().Table(table_name)
    return _assets_table


def _get_audit_table():
    """Get Audit Events table (cached)."""
    global _audit_table
    if _audit_table is None:
        table_name = os.getenv('AUDIT_TABLE', 'SIH-AuditEvents')
        _audit_table = _get_dynamodb_resource().Table(table_name)
    return _audit_table


def _user_to_item(user: User) -> dict:
    """Convert User entity to DynamoDB item."""
    return {
        'userId': user.userId,
        'name': user.name,
        'email': user.email,
        'role': user.role.value,
        'clearanceLevel': user.clearanceLevel.name,
        'unit': user.unit.value,
        'compartments': user.compartments,
        'cognitoUsername': user.cognitoUsername,
        'status': user.status,
        'createdAt': user.createdAt,
    }


def _asset_to_item(asset: DefenseAsset) -> dict:
    """Convert DefenseAsset entity to DynamoDB item."""
    return {
        'assetId': asset.assetId,
        'name': asset.name,
        'assetType': asset.assetType,
        'classification': asset.classification.name,
        'unit': asset.unit.value,
        'compartment': asset.compartment,
        'custodianId': asset.custodianId,
        'state': asset.state.value,
        'contentHash': asset.contentHash,
        'custodyChain': asset.custodyChain,
        'metadata': asset.metadata,
        'createdAt': asset.createdAt,
        'updatedAt': asset.updatedAt,
    }


def _item_to_user(item: dict) -> User:
    """Convert DynamoDB item to User entity with defensive defaults."""
    role_val = item.get('role', 'User')
    clearance_val = item.get('clearanceLevel')
    if not clearance_val:
        clearance_val = 'TOP_SECRET' if role_val == 'Admin' else 'UNCLASSIFIED'
    
    unit_val = item.get('unit')
    if not unit_val:
        unit_val = 'BEL_LABS' if role_val == 'Admin' else 'ARMY'
        
    raw_compartments = item.get('compartments', [])
    compartments = [c if isinstance(c, str) else str(c) for c in raw_compartments]

    return User(
        userId=item.get('userId', ''),
        name=item.get('name', ''),
        email=item.get('email', ''),
        role=UserRole(role_val),
        clearanceLevel=ClearanceLevel[clearance_val],
        unit=MilitaryUnit(unit_val),
        compartments=compartments,
        cognitoUsername=item.get('cognitoUsername', ''),
        status=item.get('status', 'ACTIVE'),
        createdAt=item.get('createdAt', ''),
    )


def _item_to_asset(item: dict) -> DefenseAsset:
    """Convert DynamoDB item to DefenseAsset entity defensively."""
    return DefenseAsset(
        assetId=item.get('assetId', ''),
        name=item.get('name', ''),
        assetType=item.get('assetType', 'OTHER'),
        classification=ClearanceLevel[item.get('classification', 'UNCLASSIFIED')],
        unit=MilitaryUnit(item.get('unit', 'ARMY')),
        compartment=item.get('compartment', ''),
        custodianId=item.get('custodianId', ''),
        state=AssetState(item.get('state', 'DRAFT')),
        contentHash=item.get('contentHash', ''),
        custodyChain=item.get('custodyChain', []),
        metadata=item.get('metadata', {}),
        createdAt=item.get('createdAt', ''),
        updatedAt=item.get('updatedAt', ''),
    )


def _audit_to_item(record: AuditRecord) -> dict:
    """Convert AuditRecord entity to DynamoDB item."""
    return {
        'eventId': record.eventId,
        'timestamp': record.timestamp,
        'actorId': record.actorId,
        'actorRole': record.actorRole,
        'action': record.action,
        'resourceType': record.resourceType,
        'resourceId': record.resourceId,
        'prevHash': record.prevHash,
        'currentHash': record.currentHash,
        'payloadHash': record.payloadHash,
        'details': record.details,
    }


def _item_to_audit(item: dict) -> AuditRecord:
    """Convert DynamoDB item to AuditRecord entity."""
    return AuditRecord(
        eventId=item['eventId'],
        timestamp=item['timestamp'],
        actorId=item['actorId'],
        actorRole=item['actorRole'],
        action=item['action'],
        resourceType=item['resourceType'],
        resourceId=item['resourceId'],
        prevHash=item['prevHash'],
        currentHash=item['currentHash'],
        payloadHash=item['payloadHash'],
        details=item.get('details', {}),
    )


class DynamoDbUserRepository(IUserRepository):
    """DynamoDB implementation of IUserRepository."""

    def save(self, user: User) -> None:
        """Save user with conditional write to prevent duplicates."""
        table = _get_users_table()
        item = _user_to_item(user)
        try:
            table.put_item(
                Item=item,
                ConditionExpression='attribute_not_exists(userId) AND attribute_not_exists(cognitoUsername)'
            )
        except ClientError as e:
            if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                raise ValueError(f"User with userId {user.userId} or cognitoUsername {user.cognitoUsername} already exists")
            raise

    def find_by_id(self, user_id: str) -> Optional[User]:
        """Find user by userId (primary key)."""
        table = _get_users_table()
        response = table.get_item(Key={'userId': user_id})
        item = response.get('Item')
        return _item_to_user(item) if item else None

    def find_by_cognito_username(self, cognito_username: str) -> Optional[User]:
        """Find user by cognitoUsername using GSI query with scan fallback."""
        table = _get_users_table()
        try:
            response = table.query(
                IndexName='cognitoUsername-index',
                KeyConditionExpression=Key('cognitoUsername').eq(cognito_username)
            )
            items = response.get('Items', [])
            return _item_to_user(items[0]) if items else None
        except ClientError:
            # GSI fallback: scan with filter
            response = table.scan(
                FilterExpression=Key('cognitoUsername').eq(cognito_username),
                Limit=10
            )
            items = response.get('Items', [])
            return _item_to_user(items[0]) if items else None

    def list_all(self) -> List[User]:
        """List all users (admin only - uses scan)."""
        table = _get_users_table()
        items = []
        response = table.scan(Limit=100)
        items = response.get('Items', [])
            
        return [_item_to_user(item) for item in items]


class DynamoDbAssetRepository(IAssetRepository):
    """DynamoDB implementation of IAssetRepository."""

    def save(self, asset: DefenseAsset) -> None:
        """Save asset with conditional write to prevent duplicates."""
        table = _get_assets_table()
        item = _asset_to_item(asset)
        try:
            table.put_item(
                Item=item,
                ConditionExpression='attribute_not_exists(assetId)'
            )
        except ClientError as e:
            if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                raise ValueError(f"Asset with assetId {asset.assetId} already exists")
            raise

    def find_by_id(self, asset_id: str) -> Optional[DefenseAsset]:
        """Find asset by assetId (primary key)."""
        table = _get_assets_table()
        response = table.get_item(Key={'assetId': asset_id})
        item = response.get('Item')
        return _item_to_asset(item) if item else None

    def find_by_custodian(self, custodian_id: str) -> List[DefenseAsset]:
        """Find assets by custodianId using query with scan fallback."""
        table = _get_assets_table()
        try:
            response = table.query(
                IndexName='custodianId-index',
                KeyConditionExpression=Key('custodianId').eq(custodian_id)
            )
            items = response.get('Items', [])
            return [_item_to_asset(item) for item in items]
        except ClientError:
            # GSI fallback: scan with filter
            response = table.scan(
                FilterExpression=Key('custodianId').eq(custodian_id),
                Limit=50
            )
            items = response.get('Items', [])
            return [_item_to_asset(item) for item in items]

    def update(self, asset: DefenseAsset, expected_state: Optional[AssetState] = None) -> None:
        """Update asset with optimistic locking via ConditionExpression."""
        table = _get_assets_table()
        
        if expected_state is not None:
            # Use UpdateItem with ConditionExpression for optimistic locking
            try:
                table.update_item(
                    Key={'assetId': asset.assetId},
                    UpdateExpression='SET #name = :name, #at = :at, #cls = :cls, #unit = :unit, #comp = :comp, #cid = :cid, #st = :st, #ch = :ch, #cc = :cc, #meta = :meta, #ua = :ua',
                    ExpressionAttributeNames={
                        '#name': 'name', '#at': 'assetType', '#cls': 'classification',
                        '#unit': 'unit', '#comp': 'compartment', '#cid': 'custodianId',
                        '#st': 'state', '#ch': 'contentHash', '#cc': 'custodyChain',
                        '#meta': 'metadata', '#ua': 'updatedAt'
                    },
                    ConditionExpression='#st = :expected_state',
                    ExpressionAttributeValues={
                        ':name': asset.name, ':at': asset.assetType, ':cls': asset.classification.name,
                        ':unit': asset.unit.value, ':comp': asset.compartment, ':cid': asset.custodianId,
                        ':st': asset.state.value, ':ch': asset.contentHash,
                        ':cc': asset.custodyChain, ':meta': asset.metadata, ':ua': asset.updatedAt,
                        ':expected_state': expected_state.value
                    }
                )
            except ClientError as e:
                if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                    raise ConcurrencyError(
                        f"State mismatch: expected {expected_state.value}, found different state"
                    )
                raise
        else:
            # No expected_state check - just overwrite (for initial creation or admin operations)
            item = _asset_to_item(asset)
            table.put_item(Item=item)

    def list_all(self) -> List[DefenseAsset]:
        """List all assets (uses scan - for admin/auditor only)."""
        table = _get_assets_table()
        items = []
        response = table.scan(Limit=100)
        items = response.get('Items', [])
            
        return [_item_to_asset(item) for item in items]


class DynamoDbAuditLedger(IAuditLedger):
    """DynamoDB implementation of IAuditLedger."""

    def append(self, record: AuditRecord) -> None:
        """Append immutable audit record."""
        table = _get_audit_table()
        item = _audit_to_item(record)
        table.put_item(Item=item)

    def get_last(self) -> Optional[AuditRecord]:
        """Get most recent audit record by querying timestamp descending."""
        table = _get_audit_table()
        try:
            # Query with ScanIndexForward=False to get latest first
            response = table.query(
                IndexName='timestamp-index',
                KeyConditionExpression=Key('resourceType').eq('__ALL__'),
                ScanIndexForward=False,
                Limit=1
            )
            items = response.get('Items', [])
            return _item_to_audit(items[0]) if items else None
        except ClientError:
            # Fallback: scan with limit 1 (not ideal for production)
            response = table.scan(Limit=1)
            items = response.get('Items', [])
            if items:
                items.sort(key=lambda x: x['timestamp'], reverse=True)
                return _item_to_audit(items[0])
            return None

    def get_all(self) -> List[AuditRecord]:
        """Get all audit records ordered by timestamp ascending."""
        table = _get_audit_table()
        items = []
        response = table.scan(Limit=100)
        items = response.get('Items', [])
            
        items.sort(key=lambda x: x['timestamp'])
        return [_item_to_audit(item) for item in items]

    def find_by_event_id(self, event_id: str) -> Optional[AuditRecord]:
        """Find audit record by eventId (primary key)."""
        table = _get_audit_table()
        response = table.get_item(Key={'eventId': event_id})
        item = response.get('Item')
        return _item_to_audit(item) if item else None

    def find_by_resource(self, resource_type: str, resource_id: str) -> List[AuditRecord]:
        """Find audit records for a specific resource using GSI query."""
        table = _get_audit_table()
        try:
            response = table.query(
                IndexName='resourceType-resourceId-index',
                KeyConditionExpression=Key('resourceType').eq(resource_type) & Key('resourceId').eq(resource_id)
            )
            items = response.get('Items', [])
            return [_item_to_audit(item) for item in items]
        except ClientError as e:
            if 'IndexNotFoundException' in str(e):
                raise RuntimeError("GSI 'resourceType-resourceId-index' not found on AuditEvents table")
            raise