"""Adapters Layer: Concrete secondary adapters (In-Memory, DynamoDB, PASETO, Argon2id)."""
