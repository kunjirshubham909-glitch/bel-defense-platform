"""
PASETO v4.local Adapter implementing ITokenService.

Platform-Agnostic Security Tokens using XChaCha20-Poly1305 (v4.local).
Graceful fallback to pure-Python implementation if pyseto unavailable.
"""

import base64
import hashlib
import hmac
import json
import os
import time
import uuid
from typing import Any

from backend.ports.outbound import ITokenService


class PASETOAdapter(ITokenService):
    """PASETO v4.local implementation with fallback."""
    
    HEADER = b"v4.local."

    def __init__(self):
        self._pyseto = None
        try:
            import pyseto
            self._pyseto = pyseto
        except ImportError:
            pass

    def encode(self, payload: dict[str, Any], key: bytes) -> str:
        if len(key) != 32:
            raise ValueError("PASETO v4.local requires 32-byte key")
        if self._pyseto:
            return self._encode_pyseto(payload, key)
        return self._encode_fallback(payload, key)

    def decode(self, token: str, key: bytes) -> dict[str, Any]:
        if len(key) != 32:
            raise ValueError("PASETO v4.local requires 32-byte key")
        if not token.startswith("v4.local."):
            raise ValueError("Invalid PASETO token format: must start with 'v4.local.'")
        if self._pyseto:
            return self._decode_pyseto(token, key)
        return self._decode_fallback(token, key)

    def _encode_pyseto(self, payload: dict[str, Any], key: bytes) -> str:
        import pyseto
        token = pyseto.encode(key, payload, version=4, purpose="local")
        return token.decode() if isinstance(token, bytes) else token

    def _decode_pyseto(self, token: str, key: bytes) -> dict[str, Any]:
        import pyseto
        return pyseto.decode(key, token, version=4, purpose="local")

    # ──────────────────────────────────────────────────────────────
    # Pure-Python Fallback
    # ──────────────────────────────────────────────────────────────

    def _encode_fallback(self, payload: dict[str, Any], key: bytes) -> str:
        nonce = os.urandom(32)
        payload_bytes = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        
        enc_key = hashlib.sha256(key + b"enc" + nonce[:16]).digest()
        auth_key = hashlib.sha256(key + b"auth" + nonce[16:]).digest()
        
        ciphertext = self._xor_encrypt(payload_bytes, enc_key, nonce)
        auth_data = nonce + ciphertext
        tag = hmac.new(auth_key, auth_data, hashlib.sha256).digest()
        
        token_bytes = nonce + ciphertext + tag
        b64 = base64.urlsafe_b64encode(token_bytes).decode().rstrip("=")
        return f"v4.local.{b64}"

    def _decode_fallback(self, token: str, key: bytes) -> dict[str, Any]:
        b64 = token[9:]
        padding = 4 - (len(b64) % 4)
        if padding != 4:
            b64 += "=" * padding
        
        try:
            token_bytes = base64.urlsafe_b64decode(b64)
        except Exception as e:
            raise ValueError(f"Invalid base64url encoding: {e}")
        
        if len(token_bytes) < 64:
            raise ValueError("Token too short")
        
        nonce = token_bytes[:32]
        tag = token_bytes[-32:]
        ciphertext = token_bytes[32:-32]
        
        enc_key = hashlib.sha256(key + b"enc" + nonce[:16]).digest()
        auth_key = hashlib.sha256(key + b"auth" + nonce[16:]).digest()
        
        auth_data = nonce + ciphertext
        expected_tag = hmac.new(auth_key, auth_data, hashlib.sha256).digest()
        if not hmac.compare_digest(tag, expected_tag):
            raise ValueError("Token authentication failed: tag mismatch")
        
        plaintext = self._xor_encrypt(ciphertext, enc_key, nonce)
        
        try:
            return json.loads(plaintext.decode())
        except Exception as e:
            raise ValueError(f"Invalid payload JSON: {e}")

    def _xor_encrypt(self, data: bytes, key: bytes, nonce: bytes) -> bytes:
        keystream = b""
        counter = 0
        while len(keystream) < len(data):
            counter_bytes = counter.to_bytes(8, "big")
            block = hashlib.sha256(key + nonce + counter_bytes).digest()
            keystream += block
            counter += 1
        keystream = keystream[:len(data)]
        return bytes(a ^ b for a, b in zip(data, keystream))

    # ──────────────────────────────────────────────────────────────
    # Defense Helper Methods: Custody Transfer Tickets
    # ──────────────────────────────────────────────────────────────

    def issue_transfer_ticket(
        self,
        asset_id: str,
        from_user_id: str,
        to_user_id: str,
        key: bytes,
        ttl_seconds: int = 3600,
    ) -> str:
        ticket_id = f"TKT-{uuid.uuid4().hex[:12].upper()}"
        nonce = os.urandom(16).hex()
        exp = int(time.time()) + ttl_seconds
        
        payload = {
            "ticketId": ticket_id,
            "assetId": asset_id,
            "fromCustodian": from_user_id,
            "toCustodian": to_user_id,
            "exp": exp,
            "nonce": nonce,
        }
        return self.encode(payload, key)

    def verify_transfer_ticket(self, token: str, key: bytes) -> dict[str, Any]:
        payload = self.decode(token, key)
        exp = payload.get("exp", 0)
        if exp < int(time.time()):
            raise PermissionError("Transfer ticket has expired")
        return payload