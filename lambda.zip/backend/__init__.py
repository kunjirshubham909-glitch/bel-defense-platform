"""BEL Tactical Defense Platform - Backend Core Package."""
__version__ = "2.0.0"
