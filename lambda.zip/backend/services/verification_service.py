"""
Verification Service implementing IVerificationService.

Provides ledger integrity verification and Merkle proof generation/verification
using the LMV (Lightweight Merkle Verification) engine.
"""

from typing import Any

from backend.domain.entities import AuditRecord
from backend.domain.merkle_engine import (
    MerkleTree,
    calculate_payload_hash,
    calculate_block_hash,
    GENESIS_PREV_HASH,
)
from backend.ports.inbound import IVerificationService
from backend.ports.outbound import IAuditLedger


class VerificationService(IVerificationService):
    """Application service for cryptographic verification."""

    def __init__(self, audit_ledger: IAuditLedger):
        self._audit_ledger = audit_ledger

    def verify_ledger(self, records: list[AuditRecord] | None = None) -> dict[str, Any]:
        """Verify entire audit ledger integrity."""
        if records is None:
            records = self._audit_ledger.get_all()

        if not records:
            return {
                "verified": True,
                "total_blocks": 0,
                "merkle_root": GENESIS_PREV_HASH,
                "chain_head": GENESIS_PREV_HASH,
                "message": "Empty ledger is trivially valid",
                "compromised_block_id": None,
                "block_index": None,
                "reason": None,
            }

        expected_prev_hash = GENESIS_PREV_HASH

        for idx, block in enumerate(records):
            if block.prevHash != expected_prev_hash:
                return {
                    "verified": False,
                    "total_blocks": len(records),
                    "merkle_root": "",
                    "chain_head": "",
                    "message": "Chain linkage broken",
                    "compromised_block_id": block.eventId,
                    "block_index": idx,
                    "reason": f"PrevHash broken at block {block.eventId}. Expected {expected_prev_hash}, got {block.prevHash}",
                }

            expected_payload_hash = calculate_payload_hash(
                actor_id=block.actorId,
                actor_role=block.actorRole,
                action=block.action,
                resource_type=block.resourceType,
                resource_id=block.resourceId,
                timestamp=block.timestamp,
                details=block.details,
            )
            if block.payloadHash != expected_payload_hash:
                return {
                    "verified": False,
                    "total_blocks": len(records),
                    "merkle_root": "",
                    "chain_head": "",
                    "message": "Payload hash mismatch",
                    "compromised_block_id": block.eventId,
                    "block_index": idx,
                    "reason": f"Payload hash mismatch at block {block.eventId}. Data was modified!",
                }

            expected_current_hash = calculate_block_hash(
                prev_hash=block.prevHash,
                timestamp=block.timestamp,
                payload_hash=block.payloadHash,
            )
            if block.currentHash != expected_current_hash:
                return {
                    "verified": False,
                    "total_blocks": len(records),
                    "merkle_root": "",
                    "chain_head": "",
                    "message": "Block currentHash corrupted",
                    "compromised_block_id": block.eventId,
                    "block_index": idx,
                    "reason": f"Block currentHash corrupted at block {block.eventId}.",
                }

            expected_prev_hash = block.currentHash

        tree = MerkleTree([b.currentHash for b in records])
        return {
            "verified": True,
            "total_blocks": len(records),
            "merkle_root": tree.get_root(),
            "chain_head": records[-1].currentHash,
            "message": "LEDGER INTEGRITY 100% VERIFIED",
            "compromised_block_id": None,
            "block_index": None,
            "reason": None,
        }

    def get_merkle_proof_for_event(self, event_id: str) -> dict[str, Any]:
        """Generate Merkle inclusion proof for a specific event."""
        records = self._audit_ledger.get_all()
        
        target_idx = None
        target_record = None
        for idx, record in enumerate(records):
            if record.eventId == event_id:
                target_idx = idx
                target_record = record
                break
        
        if target_idx is None or target_record is None:
            raise ValueError(f"Event {event_id} not found in ledger")

        tree = MerkleTree([b.currentHash for b in records])
        proof = tree.get_inclusion_proof(target_idx)
        
        return {
            "eventId": event_id,
            "leafHash": target_record.currentHash,
            "merkleRoot": tree.get_root(),
            "proof": proof,
        }

    def verify_merkle_proof(self, leaf_hash: str, proof: list[dict[str, str]], root: str) -> bool:
        """Verify a Merkle inclusion proof using static MerkleTree method."""
        return MerkleTree.verify_inclusion_proof(leaf_hash, proof, root)

    def generate_merkle_root(self, leaves: list[str]) -> str:
        """Generate Merkle root from leaf hashes."""
        return MerkleTree(leaves).get_root()