"""Services Layer: Application business logic orchestrating domain entities and outbound ports."""
