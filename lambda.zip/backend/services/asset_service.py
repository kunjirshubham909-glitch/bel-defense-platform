"""
Asset service implementing IAssetService with state machine and ABAC integration.
"""

import hashlib
import json
import uuid
from datetime import datetime, timezone
from typing import Any

from backend.adapters.paseto_adapter import PASETOAdapter
from backend.domain.entities import (
    AssetState,
    AuditRecord,
    ClearanceLevel,
    DefenseAsset,
    MilitaryUnit,
    User,
    UserRole,
)
from backend.domain.merkle_engine import (
    GENESIS_PREV_HASH,
    calculate_block_hash,
    calculate_payload_hash,
)
from backend.domain.state_machine import (
    InvalidStateTransitionError,
    UnauthorizedStateChangeError,
    transition_asset_state,
)
from backend.ports.inbound import IAssetService
from backend.ports.outbound import IAssetRepository, IAuditLedger, IUserRepository


class AssetService(IAssetService):
    """Application service managing defense asset lifecycle, ABAC access, and custody transfers."""

    def __init__(
        self,
        asset_repo: IAssetRepository,
        user_repo: IUserRepository,
        audit_ledger: IAuditLedger,
    ):
        self._asset_repo = asset_repo
        self._user_repo = user_repo
        self._audit_ledger = audit_ledger
        self._paseto = PASETOAdapter()

    def _audit(
        self,
        actor: User,
        action: str,
        rtype: str,
        rid: str,
        details: dict[str, Any],
    ) -> AuditRecord:
        last = self._audit_ledger.get_last()
        prev_hash = last.currentHash if last else GENESIS_PREV_HASH
        timestamp = datetime.now(timezone.utc).isoformat()
        payload_hash = calculate_payload_hash(
            actor_id=actor.userId,
            actor_role=actor.role.value,
            action=action,
            resource_type=rtype,
            resource_id=rid,
            timestamp=timestamp,
            details=details,
        )
        current_hash = calculate_block_hash(prev_hash, timestamp, payload_hash)
        return AuditRecord(
            eventId=str(uuid.uuid4()),
            timestamp=timestamp,
            actorId=actor.userId,
            actorRole=actor.role.value,
            action=action,
            resourceType=rtype,
            resourceId=rid,
            prevHash=prev_hash,
            currentHash=current_hash,
            payloadHash=payload_hash,
            details=details,
        )

    def _check(self, user: User, asset: DefenseAsset) -> dict[str, Any]:
        """Evaluate ABAC clearance rule."""
        if user.role == UserRole.ADMIN:
            return {"allowed": True, "reason": "Admin bypass"}
        if user.clearanceLevel < asset.classification:
            return {
                "allowed": False,
                "reason": f"Insufficient clearance: user={user.clearanceLevel.name}, asset={asset.classification.name}",
            }
        if user.unit == asset.unit:
            return {"allowed": True, "reason": f"Same unit: {user.unit.value}"}
        if asset.compartment in user.compartments:
            return {"allowed": True, "reason": f"Compartment access: {asset.compartment}"}
        return {
            "allowed": False,
            "reason": f"Unit mismatch: user={user.unit.value}, asset={asset.unit.value}, no compartment access",
        }

    def register_asset(self, actor: User, data: dict[str, Any]) -> DefenseAsset:
        """Register a new defense asset."""
        if actor.role not in (UserRole.ADMIN, UserRole.MANAGER):
            raise PermissionError("Only Manager or Admin can register assets")

        aid = data.get("assetId") or str(uuid.uuid4())
        name = data.get("name")
        at = data.get("assetType")
        cls_val = data.get("classification", "UNCLASSIFIED")
        unit_val = data.get("unit", "ARMY")
        comp = data.get("compartment", "")
        cid = data.get("custodianId", actor.userId)
        meta = data.get("metadata", {})

        if not name:
            raise ValueError("name required")
        if not at:
            raise ValueError("assetType required")
        if not comp:
            raise ValueError("compartment required")

        try:
            classification = (
                ClearanceLevel[cls_val]
                if isinstance(cls_val, str)
                else ClearanceLevel(cls_val)
            )
        except Exception:
            raise ValueError(f"Invalid classification: {cls_val}")

        try:
            if isinstance(unit_val, str):
                try:
                    unit = MilitaryUnit(unit_val)
                except ValueError:
                    unit = MilitaryUnit[unit_val.upper()]
            else:
                unit = MilitaryUnit(unit_val)
        except Exception:
            raise ValueError(f"Invalid unit: {unit_val}")

        cust = self._user_repo.find_by_id(cid)
        if not cust:
            raise ValueError(f"Custodian {cid} not found")

        content = hashlib.sha256(
            f"{aid}{name}{at}{classification.name}{unit.value}{comp}{cid}".encode()
        ).hexdigest()
        istate = AssetState.REGISTERED if actor.role == UserRole.ADMIN else AssetState.DRAFT

        asset = DefenseAsset(
            assetId=aid,
            name=name,
            assetType=at,
            classification=classification,
            unit=unit,
            compartment=comp,
            custodianId=cid,
            state=istate,
            contentHash=content,
            metadata=meta,
            custodyChain=[
                {
                    "custodianId": cid,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "action": "INITIAL_CUSTODY",
                }
            ],
        )

        self._asset_repo.save(asset)
        self._audit_ledger.append(
            self._audit(
                actor,
                "ASSET_REGISTER",
                "Asset",
                aid,
                {
                    "name": name,
                    "classification": classification.name,
                    "unit": unit.value,
                    "initial_state": istate.value,
                },
            )
        )
        return asset

    def get_asset(self, actor: User, aid: str) -> DefenseAsset:
        """Get asset by ID with ABAC evaluation."""
        asset = self._asset_repo.find_by_id(aid)
        if not asset:
            raise ValueError(f"Asset {aid} not found")

        acc = self._check(actor, asset)
        if not acc["allowed"]:
            self._audit_ledger.append(
                self._audit(
                    actor,
                    "SECURITY_CLEARANCE_DENIED",
                    "Asset",
                    aid,
                    {"reason": acc["reason"]},
                )
            )
            raise PermissionError(f"Access denied: {acc['reason']}")
        return asset

    def list_assets(self, actor: User) -> list[DefenseAsset]:
        """List assets visible to caller based on ABAC clearance."""
        return [a for a in self._asset_repo.list_all() if self._check(actor, a)["allowed"]]

    def transfer_custody(
        self,
        actor: User,
        aid: str,
        ncid: str,
        transfer_ticket: str | None = None,
        key: bytes | None = None,
    ) -> DefenseAsset:
        """Transfer asset custody to another user with optional PASETO ticket verification."""
        asset = self._asset_repo.find_by_id(aid)
        if not asset:
            raise ValueError(f"Asset {aid} not found")

        acc = self._check(actor, asset)
        if not acc["allowed"]:
            self._audit_ledger.append(
                self._audit(
                    actor,
                    "SECURITY_CLEARANCE_DENIED",
                    "Asset",
                    aid,
                    {"reason": acc["reason"], "attempted_action": "TRANSFER_CUSTODY"},
                )
            )
            raise PermissionError(f"Access denied: {acc['reason']}")

        nc = self._user_repo.find_by_id(ncid)
        if not nc:
            raise ValueError(f"New custodian {ncid} not found")

        if nc.clearanceLevel < asset.classification:
            raise PermissionError(
                f"Recipient clearance {nc.clearanceLevel.name} insufficient for asset classification {asset.classification.name}"
            )

        ticket_id = None
        if transfer_ticket and key:
            ticket = self._paseto.verify_transfer_ticket(transfer_ticket, key)
            if ticket.get("assetId") != aid:
                raise PermissionError("Transfer ticket assetId mismatch")
            if ticket.get("toCustodian") != ncid:
                raise PermissionError("Transfer ticket toCustodian mismatch")
            ticket_id = ticket.get("ticketId")

        try:
            ns = transition_asset_state(
                asset.state,
                AssetState.IN_TRANSIT,
                is_admin=(actor.role == UserRole.ADMIN),
            )
        except (InvalidStateTransitionError, UnauthorizedStateChangeError) as e:
            raise ValueError(f"Invalid state transition: {e}")

        ce = {
            "custodianId": ncid,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "action": "TRANSFER",
            "from": asset.custodianId,
            "by": actor.userId,
        }
        if ticket_id:
            ce["ticketId"] = ticket_id

        asset.custodyChain.append(ce)
        asset.custodianId = ncid
        asset.state = ns
        asset.updatedAt = datetime.now(timezone.utc).isoformat()

        self._asset_repo.update(asset, expected_state=asset.state)

        audit_details = {
            "from_custodian": ce["from"],
            "to_custodian": ncid,
            "new_state": ns.value,
        }
        if ticket_id:
            audit_details["ticketId"] = ticket_id

        self._audit_ledger.append(self._audit(actor, "CUSTODY_TRANSFER", "Asset", aid, audit_details))
        return asset

    def decommission_asset(self, actor: User, aid: str) -> DefenseAsset:
        """Decommission an asset (Admin only)."""
        if actor.role != UserRole.ADMIN:
            raise PermissionError("Only Admin can decommission assets")

        asset = self._asset_repo.find_by_id(aid)
        if not asset:
            raise ValueError(f"Asset {aid} not found")

        try:
            ns = transition_asset_state(asset.state, AssetState.DECOMMISSIONED, is_admin=True)
        except (InvalidStateTransitionError, UnauthorizedStateChangeError) as e:
            raise ValueError(f"Invalid state transition: {e}")

        prev_state = asset.state
        asset.state = ns
        asset.updatedAt = datetime.now(timezone.utc).isoformat()

        self._asset_repo.update(asset, expected_state=asset.state)
        self._audit_ledger.append(
            self._audit(
                actor,
                "ASSET_DECOMMISSIONED",
                "Asset",
                aid,
                {"previous_state": prev_state.value, "new_state": ns.value},
            )
        )
        return asset