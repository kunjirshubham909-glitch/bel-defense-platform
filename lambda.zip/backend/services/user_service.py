"""
User service implementing IUserService with ABAC clearance evaluation.

Orchestrates user management use cases using injected repository and audit ports.
"""

import re
import uuid
from datetime import datetime, timezone
from typing import Any

from backend.domain.entities import User, DefenseAsset, UserRole, ClearanceLevel, MilitaryUnit, AuditRecord
from backend.domain.merkle_engine import (
    calculate_payload_hash,
    calculate_block_hash,
    GENESIS_PREV_HASH,
)
from backend.ports.inbound import IUserService
from backend.ports.outbound import IUserRepository, IAuditLedger


class UserService(IUserService):
    """Application service for user management with ABAC clearance evaluation."""

    EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")

    def __init__(self, user_repo: IUserRepository, audit_ledger: IAuditLedger):
        self._user_repo = user_repo
        self._audit_ledger = audit_ledger

    def create_user(self, creator: User, data: dict[str, Any]) -> User:
        if creator.role != UserRole.ADMIN:
            raise PermissionError("Only Admin can create users")

        user_id = data.get("userId") or str(uuid.uuid4())
        name = data.get("name")
        email = data.get("email")
        role_str = data.get("role", "User")
        clearance_str = data.get("clearanceLevel", "UNCLASSIFIED")
        unit_str = data.get("unit", "ARMY")
        compartments = data.get("compartments", [])
        cognito_username = data.get("cognitoUsername", user_id)

        if not name:
            raise ValueError("name is required")
        if not email:
            raise ValueError("email is required")
        if not self.EMAIL_REGEX.match(email):
            raise ValueError("Invalid email format")

        try:
            role = UserRole(role_str)
        except ValueError:
            raise ValueError(f"Invalid role: {role_str}. Valid: {[r.value for r in UserRole]}")

        try:
            clearance = ClearanceLevel[clearance_str] if isinstance(clearance_str, str) else ClearanceLevel(clearance_str)
        except (KeyError, ValueError):
            raise ValueError(f"Invalid clearanceLevel: {clearance_str}. Valid: {[c.name for c in ClearanceLevel]}")

        try:
            unit = MilitaryUnit(unit_str)
        except ValueError:
            try:
                unit = MilitaryUnit[unit_str.upper()]
            except KeyError:
                raise ValueError(f"Invalid unit: {unit_str}. Valid: {[u.value for u in MilitaryUnit]}")

        if self._user_repo.find_by_id(user_id):
            raise ValueError(f"User with userId {user_id} already exists")
        if self._user_repo.find_by_cognito_username(cognito_username):
            raise ValueError(f"User with cognitoUsername {cognito_username} already exists")

        user = User(
            userId=user_id, name=name, email=email, role=role,
            clearanceLevel=clearance, unit=unit, compartments=compartments,
            cognitoUsername=cognito_username,
        )

        self._user_repo.save(user)
        self._audit_ledger.append(self._make_audit_record(
            actor=creator, action="USER_CREATE", resource_type="User", resource_id=user_id,
            details={"created_user": user_id, "role": role.value, "clearance": clearance.name, "unit": unit.value},
        ))
        return user

    def get_user_by_id(self, user_id: str) -> User | None:
        return self._user_repo.find_by_id(user_id)

    def get_user_by_cognito(self, cognito_username: str) -> User | None:
        return self._user_repo.find_by_cognito_username(cognito_username)

    def list_users(self) -> list[User]:
        return self._user_repo.list_all()

    def can_access(self, user: User, asset: DefenseAsset) -> dict[str, Any]:
        """Evaluate ABAC clearance for user accessing asset."""
        if user.role == UserRole.ADMIN:
            return {"allowed": True, "reason": "Admin bypass"}

        if user.clearanceLevel < asset.classification:
            return {"allowed": False, "reason": f"Insufficient clearance: user={user.clearanceLevel.name}, asset={asset.classification.name}"}

        if user.unit == asset.unit:
            return {"allowed": True, "reason": f"Same unit: {user.unit.value}"}

        if asset.compartment in user.compartments:
            return {"allowed": True, "reason": f"Compartment access: {asset.compartment}"}

        return {"allowed": False, "reason": f"Unit mismatch: user={user.unit.value}, asset={asset.unit.value}, no compartment access"}

    def _make_audit_record(self, actor: User, action: str, resource_type: str, resource_id: str, details: dict[str, Any]) -> AuditRecord:
        """Create an audit record using centralized merkle_engine hash functions."""
        last = self._audit_ledger.get_last()
        prev_hash = last.currentHash if last else GENESIS_PREV_HASH
        timestamp = datetime.now(timezone.utc).isoformat()
        
        payload_hash = calculate_payload_hash(
            actor_id=actor.userId,
            actor_role=actor.role.value,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            timestamp=timestamp,
            details=details,
        )
        current_hash = calculate_block_hash(prev_hash, timestamp, payload_hash)
        
        return AuditRecord(
            eventId=str(uuid.uuid4()),
            timestamp=timestamp,
            actorId=actor.userId,
            actorRole=actor.role.value,
            action=action,
            resourceType=resource_type,
            resourceId=resource_id,
            prevHash=prev_hash,
            currentHash=current_hash,
            payloadHash=payload_hash,
            details=details,
        )