"""Domain Layer: Pure entities, state machines, and cryptographic engines with zero external cloud dependencies."""
