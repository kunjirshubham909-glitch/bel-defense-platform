"""
Pure domain entities with ZERO external dependencies.

This module defines the core domain models for the Defense Asset Management System.
All entities are pure Python dataclasses/enums with no AWS, framework, or external dependencies.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import IntEnum, StrEnum
from typing import Any
import re


class ClearanceLevel(IntEnum):
    """Security clearance levels (higher value = higher clearance)."""
    UNCLASSIFIED = 0
    RESTRICTED = 1
    CONFIDENTIAL = 2
    SECRET = 3
    TOP_SECRET = 4


class MilitaryUnit(StrEnum):
    """Armed forces units and BEL Labs."""
    ARMY = "Army"
    NAVY = "Navy"
    AIR_FORCE = "AirForce"
    BEL_LABS = "BEL_Labs"


class AssetState(StrEnum):
    """Legal states for a defense asset."""
    DRAFT = "DRAFT"
    REGISTERED = "REGISTERED"
    ASSIGNED = "ASSIGNED"
    IN_TRANSIT = "IN_TRANSIT"
    IN_INSPECTION = "IN_INSPECTION"
    DECOMMISSIONED = "DECOMMISSIONED"


class UserRole(StrEnum):
    """User roles in the system."""
    ADMIN = "Admin"
    MANAGER = "Manager"
    AUDITOR = "Auditor"
    USER = "User"


EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")


@dataclass(slots=True)
class User:
    """User entity representing a defense personnel."""
    userId: str
    name: str
    email: str
    role: UserRole
    clearanceLevel: ClearanceLevel
    unit: MilitaryUnit
    compartments: list[str] = field(default_factory=list)
    cognitoUsername: str = ""
    status: str = "ACTIVE"
    createdAt: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def __post_init__(self):
        if isinstance(self.role, str):
            self.role = UserRole(self.role)
        if isinstance(self.clearanceLevel, int):
            self.clearanceLevel = ClearanceLevel(self.clearanceLevel)
        if isinstance(self.unit, str):
            # Try to match by value (e.g., "Army") or by name (e.g., "ARMY")
            try:
                self.unit = MilitaryUnit(self.unit)
            except ValueError:
                # Try uppercase name
                self.unit = MilitaryUnit[self.unit.upper()]
        if not self.cognitoUsername:
            self.cognitoUsername = self.userId
        if not EMAIL_REGEX.match(self.email):
            raise ValueError("Invalid email format")


@dataclass(slots=True)
class DefenseAsset:
    """Defense asset entity with custody tracking."""
    assetId: str
    name: str
    assetType: str
    classification: ClearanceLevel
    unit: MilitaryUnit
    compartment: str
    custodianId: str
    state: AssetState
    contentHash: str
    custodyChain: list[dict] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    createdAt: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    updatedAt: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def __post_init__(self):
        if isinstance(self.classification, int):
            self.classification = ClearanceLevel(self.classification)
        if isinstance(self.unit, str):
            self.unit = MilitaryUnit(self.unit)
        if isinstance(self.state, str):
            self.state = AssetState(self.state)


@dataclass(slots=True)
class AuditRecord:
    """Immutable audit record with cryptographic chaining."""
    eventId: str
    timestamp: str
    actorId: str
    actorRole: str
    action: str
    resourceType: str
    resourceId: str
    prevHash: str
    currentHash: str
    payloadHash: str
    details: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()