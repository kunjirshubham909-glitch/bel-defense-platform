"""
Pure domain cryptography engine with ZERO external dependencies.

Implements SHA-256 block-hash chaining and Binary Merkle Tree (LMV)
for Lightweight Merkle Verification of audit ledger integrity.
"""

import hashlib
import json
from typing import Any


# ──────────────────────────────────────────────────────────────
# Constants
# ──────────────────────────────────────────────────────────────
GENESIS_PREV_HASH = "0" * 64


# ──────────────────────────────────────────────────────────────
# Hash Generation Functions
# ──────────────────────────────────────────────────────────────

def hash_sha256(data: str | bytes) -> str:
    """
    Returns 64-character lowercase hex string of SHA-256 digest.
    """
    if isinstance(data, str):
        data = data.encode()
    return hashlib.sha256(data).hexdigest()


def calculate_payload_hash(
    actor_id: str,
    actor_role: str,
    action: str,
    resource_type: str,
    resource_id: str,
    timestamp: str,
    details: dict[str, Any],
) -> str:
    """
    Deterministic payload serialization using canonical JSON.
    Returns SHA-256 hex digest of the canonical JSON string.
    """
    canonical = {
        "actorId": actor_id,
        "actorRole": actor_role,
        "action": action,
        "resourceType": resource_type,
        "resourceId": resource_id,
        "timestamp": timestamp,
        "details": details,
    }
    # sort_keys=True ensures deterministic ordering
    # separators=(',', ':') removes whitespace for minimal canonical form
    payload_json = json.dumps(canonical, sort_keys=True, separators=(",", ":"))
    return hash_sha256(payload_json)


def calculate_block_hash(prev_hash: str, timestamp: str, payload_hash: str) -> str:
    """
    Computes SHA-256 of: f"{prev_hash}:{timestamp}:{payload_hash}".
    Returns 64-character hex string.
    """
    return hash_sha256(f"{prev_hash}:{timestamp}:{payload_hash}")


# ──────────────────────────────────────────────────────────────
# Binary Merkle Tree (LMV - Lightweight Merkle Verification)
# ──────────────────────────────────────────────────────────────

class MerkleTree:
    """
    Binary Merkle Tree for O(log N) inclusion proofs.
    
    Leaf level (level 0) contains the input hashes.
    Each parent = hash_sha256(left_child + right_child).
    Odd leaf count at any level: duplicate the last leaf.
    """

    def __init__(self, leaves: list[str]):
        """
        Initialize tree with leaf hashes.
        
        Args:
            leaves: List of 64-char hex strings (e.g., block currentHashes)
        """
        self._leaves = leaves[:] if leaves else []
        self._levels: list[list[str]] = []
        self._build_tree()

    def _build_tree(self) -> None:
        """
        Build complete tree from leaves up to root.
        Stores all levels in self._levels where:
        - levels[0] = leaves
        - levels[-1] = [root]
        """
        if not self._leaves:
            self._levels = [[hash_sha256("")]]
            return

        current_level = self._leaves[:]
        self._levels = [current_level[:]]

        while len(current_level) > 1:
            next_level = []
            # Handle odd count by duplicating last element
            for i in range(0, len(current_level), 2):
                left = current_level[i]
                right = current_level[i + 1] if i + 1 < len(current_level) else current_level[i]
                parent = hash_sha256(left + right)
                next_level.append(parent)
            current_level = next_level
            self._levels.append(current_level[:])

    def get_root(self) -> str:
        """Returns 64-character hex Merkle root."""
        return self._levels[-1][0]

    def get_inclusion_proof(self, leaf_index: int) -> list[dict[str, str]]:
        """
        Computes Merkle inclusion proof for leaf at leaf_index.
        
        Returns list of steps: [{"hash": sibling_hash, "direction": "LEFT"|"RIGHT"}]
        """
        if leaf_index < 0 or leaf_index >= len(self._leaves):
            raise IndexError(f"leaf_index {leaf_index} out of range (0-{len(self._leaves)-1})")

        proof = []
        index = leaf_index

        # Traverse from leaf level up to (but not including) root level
        for level in range(len(self._levels) - 1):
            level_nodes = self._levels[level]
            sibling_idx = index ^ 1  # XOR with 1 gives sibling (0↔1, 2↔3, etc.)
            
            # Determine if sibling is to the right or left of current node
            if sibling_idx < len(level_nodes):
                sibling_hash = level_nodes[sibling_idx]
                direction = "RIGHT" if sibling_idx > index else "LEFT"
                proof.append({"hash": sibling_hash, "direction": direction})
            
            # Move to parent index
            index //= 2

        return proof

    @staticmethod
    def verify_inclusion_proof(leaf_hash: str, proof: list[dict[str, str]], expected_root: str) -> bool:
        """
        Light-client Merkle inclusion proof verification.
        
        Algorithm:
        - Start with current = leaf_hash
        - For each proof step:
            if direction == "RIGHT": current = hash_sha256(current + sibling)
            else:                    current = hash_sha256(sibling + current)
        - Return current == expected_root
        """
        current = leaf_hash
        for step in proof:
            sibling = step["hash"]
            direction = step["direction"]
            if direction == "RIGHT":
                current = hash_sha256(current + sibling)
            else:  # "LEFT"
                current = hash_sha256(sibling + current)
        return current == expected_root