"""
Asset state machine enforcing legal state transitions.

This module defines the valid state transitions for defense assets and validates
all state changes. No external dependencies.
"""

from backend.domain.entities import AssetState


class DomainError(Exception):
    """Base exception for domain errors."""
    pass


class InvalidStateTransitionError(DomainError):
    """Raised when an illegal state transition is attempted."""

    def __init__(self, current_state: AssetState, target_state: AssetState, message: str | None = None):
        self.current_state = current_state
        self.target_state = target_state
        default_msg = f"Illegal transition: {current_state.value} -> {target_state.value}"
        super().__init__(message or default_msg)


class UnauthorizedStateChangeError(DomainError):
    """Raised when a non-admin attempts a privileged state change."""

    def __init__(self, target_state: AssetState, message: str | None = None):
        self.target_state = target_state
        default_msg = f"Unauthorized: only Admin can transition to {target_state.value}"
        super().__init__(message or default_msg)


# Legal state transitions mapping: current_state -> set of allowed target states
LEGAL_TRANSITIONS: dict[AssetState, set[AssetState]] = {
    AssetState.DRAFT: {AssetState.REGISTERED},
    AssetState.REGISTERED: {AssetState.ASSIGNED, AssetState.DECOMMISSIONED},
    AssetState.ASSIGNED: {AssetState.IN_TRANSIT, AssetState.IN_INSPECTION, AssetState.DECOMMISSIONED},
    AssetState.IN_TRANSIT: {AssetState.ASSIGNED, AssetState.DECOMMISSIONED},
    AssetState.IN_INSPECTION: {AssetState.ASSIGNED, AssetState.DECOMMISSIONED},
    AssetState.DECOMMISSIONED: set(),  # Terminal state
}


def transition_asset_state(current: AssetState, target: AssetState, is_admin: bool = False) -> AssetState:
    """
    Validate and return the new asset state after transition.

    Args:
        current: Current asset state
        target: Desired target state
        is_admin: Whether the actor has Admin role (required for DECOMMISSIONED)

    Returns:
        The validated target state

    Raises:
        InvalidStateTransitionError: If the transition is not legal
        UnauthorizedStateChangeError: If non-admin attempts DECOMMISSIONED
    """
    if current == target:
        return current

    allowed_targets = LEGAL_TRANSITIONS.get(current, set())
    if target not in allowed_targets:
        raise InvalidStateTransitionError(current, target)

    # DECOMMISSIONED requires admin privilege
    if target == AssetState.DECOMMISSIONED and not is_admin:
        raise UnauthorizedStateChangeError(target)

    return target