"""
Driving ports (inbound interfaces) - Use case abstractions.

These interfaces define the application use cases that driving adapters (Lambda, CLI)
will invoke. Zero external dependencies - pure Python ABCs.
"""

from abc import ABC, abstractmethod
from typing import Any

from backend.domain.entities import User, DefenseAsset, AuditRecord, ClearanceLevel, MilitaryUnit, AssetState, UserRole


class IUserService(ABC):
    """Use cases for user management."""

    @abstractmethod
    def create_user(self, creator: User, data: dict[str, Any]) -> User:
        """Create a new user (Admin only)."""
        ...

    @abstractmethod
    def get_user_by_id(self, user_id: str) -> User | None:
        """Get user by userId."""
        ...

    @abstractmethod
    def get_user_by_cognito(self, cognito_username: str) -> User | None:
        """Get user by Cognito username."""
        ...

    @abstractmethod
    def list_users(self) -> list[User]:
        """List all users."""
        ...

    @abstractmethod
    def can_access(self, user: User, asset: DefenseAsset) -> dict[str, Any]:
        """
        Evaluate ABAC clearance for user accessing asset.

        Returns: {"allowed": bool, "reason": str}
        """
        ...


class IAssetService(ABC):
    """Use cases for asset management."""

    @abstractmethod
    def register_asset(self, actor: User, data: dict[str, Any]) -> DefenseAsset:
        """Register a new defense asset (Manager/Admin only)."""
        ...

    @abstractmethod
    def get_asset(self, actor: User, asset_id: str) -> DefenseAsset:
        """Get asset by ID with ABAC check."""
        ...

    @abstractmethod
    def transfer_custody(
        self,
        actor: User,
        asset_id: str,
        new_custodian_id: str,
        transfer_ticket: str | None = None,
        key: bytes | None = None,
    ) -> DefenseAsset:
        """
        Transfer asset custody to another user.
        
        If transfer_ticket and key are provided, validates PASETO v4.local custody transfer ticket.
        """
        ...

    @abstractmethod
    def list_assets(self, actor: User) -> list[DefenseAsset]:
        """List assets visible to the actor (ABAC filtered)."""
        ...

    @abstractmethod
    def decommission_asset(self, actor: User, asset_id: str) -> DefenseAsset:
        """Decommission an asset (Admin only)."""
        ...


class IAuditService(ABC):
    """Use cases for audit logging."""

    @abstractmethod
    def record_event(
        self,
        actor: User,
        action: str,
        resource_type: str,
        resource_id: str,
        details: dict[str, Any] | None = None,
        prev_hash: str | None = None,
    ) -> AuditRecord:
        """Record an audit event with cryptographic chaining."""
        ...

    @abstractmethod
    def get_audit_trail(self, resource_type: str, resource_id: str) -> list[AuditRecord]:
        """Get audit trail for a specific resource."""
        ...

    @abstractmethod
    def get_last_event(self) -> AuditRecord | None:
        """Get the most recent audit event."""
        ...


class IVerificationService(ABC):
    """Use cases for cryptographic verification."""

    @abstractmethod
    def verify_merkle_proof(self, leaf_hash: str, proof: list[dict[str, str]], root: str) -> bool:
        """Verify a Merkle inclusion proof."""
        ...

    @abstractmethod
    def generate_merkle_root(self, leaves: list[str]) -> str:
        """Generate Merkle root from leaf hashes."""
        ...

    @abstractmethod
    def verify_ledger(self, records: list[AuditRecord] | None = None) -> dict[str, Any]:
        """
        Verify entire audit ledger integrity.
        
        Returns: {"verified": bool, "total_blocks": int, "merkle_root": str, 
                  "chain_head": str, "message": str, 
                  "compromised_block_id": str|None, "block_index": int|None, "reason": str|None}
        """
        ...

    @abstractmethod
    def get_merkle_proof_for_event(self, event_id: str) -> dict[str, Any]:
        """
        Generate Merkle inclusion proof for a specific event.
        
        Returns: {"eventId": str, "leafHash": str, "merkleRoot": str, "proof": list[dict]}
        """
        ...