"""
Driven ports (outbound interfaces) - Repository and Service abstractions.

These interfaces define the contracts that concrete adapters must implement.
Zero external dependencies - pure Python ABCs.
"""

from abc import ABC, abstractmethod
from typing import Any

from backend.domain.entities import User, DefenseAsset, AuditRecord, ClearanceLevel, MilitaryUnit, AssetState


class IUserRepository(ABC):
    """Abstract interface for user persistence."""

    @abstractmethod
    def save(self, user: User) -> None:
        """Persist a new user."""
        ...

    @abstractmethod
    def find_by_id(self, user_id: str) -> User | None:
        """Find user by userId."""
        ...

    @abstractmethod
    def find_by_cognito_username(self, cognito_username: str) -> User | None:
        """Find user by Cognito username (email)."""
        ...

    @abstractmethod
    def list_all(self) -> list[User]:
        """List all users."""
        ...


class IAssetRepository(ABC):
    """Abstract interface for asset persistence."""

    @abstractmethod
    def save(self, asset: DefenseAsset) -> None:
        """Persist a new asset."""
        ...

    @abstractmethod
    def find_by_id(self, asset_id: str) -> DefenseAsset | None:
        """Find asset by assetId."""
        ...

    @abstractmethod
    def find_by_custodian(self, custodian_id: str) -> list[DefenseAsset]:
        """Find all assets currently held by a custodian."""
        ...

    @abstractmethod
    def update(self, asset: DefenseAsset, expected_state: AssetState | None = None) -> None:
        """
        Update an existing asset with optimistic locking.

        Args:
            asset: The asset with updated fields
            expected_state: If provided, only succeeds if asset's current state matches
        """
        ...

    @abstractmethod
    def list_all(self) -> list[DefenseAsset]:
        """List all assets."""
        ...


class IAuditLedger(ABC):
    """Abstract interface for append-only audit ledger."""

    @abstractmethod
    def append(self, record: AuditRecord) -> None:
        """Append an immutable audit record."""
        ...

    @abstractmethod
    def get_last(self) -> AuditRecord | None:
        """Get the most recent audit record (for hash chaining)."""
        ...

    @abstractmethod
    def get_all(self) -> list[AuditRecord]:
        """Get all audit records in order."""
        ...

    @abstractmethod
    def find_by_event_id(self, event_id: str) -> AuditRecord | None:
        """Find audit record by eventId."""
        ...

    @abstractmethod
    def find_by_resource(self, resource_type: str, resource_id: str) -> list[AuditRecord]:
        """Find audit records for a specific resource."""
        ...


class ITokenService(ABC):
    """Abstract interface for PASETO v4 token operations."""

    @abstractmethod
    def encode(self, payload: dict[str, Any], key: bytes) -> str:
        """Encode payload into a PASETO v4.local token."""
        ...

    @abstractmethod
    def decode(self, token: str, key: bytes) -> dict[str, Any]:
        """Decode and verify a PASETO v4.local token."""
        ...


class IPasswordHasher(ABC):
    """Abstract interface for Argon2id password hashing."""

    @abstractmethod
    def hash(self, password: str) -> str:
        """Hash a password using Argon2id."""
        ...

    @abstractmethod
    def verify(self, password: str, hashed: str) -> bool:
        """Verify a password against its Argon2id hash."""
        ...