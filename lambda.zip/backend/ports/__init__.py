"""Ports Layer: Abstract base class interfaces for driving inbound use-cases and driven outbound adapters."""
