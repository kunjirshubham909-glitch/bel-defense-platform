"""
Lambda Function - API Gateway v2 HTTP API Dispatcher.

This is the primary inbound driving adapter for the Defense Asset Management System.
Routes API Gateway v2 HTTP events to appropriate service methods with proper
authentication, authorization, and standardized response envelopes.
"""

import os
import json
import re
from typing import Any, Optional, Dict, List

# Import all services and adapters
from backend.adapters.in_memory_repo import InMemoryUserRepository, InMemoryAssetRepository, InMemoryAuditLedger
from backend.services.user_service import UserService
from backend.services.asset_service import AssetService
from backend.services.verification_service import VerificationService
from backend.adapters.paseto_adapter import PASETOAdapter
from backend.adapters.argon2_adapter import Argon2Adapter
from backend.domain.entities import User, UserRole, ClearanceLevel, MilitaryUnit


# Module-level service initialization (Lambda warm start optimization)
_user_service: Optional[UserService] = None
_asset_service: Optional[AssetService] = None
_verification_service: Optional[VerificationService] = None
_audit_ledger: Optional[Any] = None
_paseto_adapter: Optional[PASETOAdapter] = None
_master_key: Optional[bytes] = None
_initialized: bool = False
def _init_services():
    """Lazy initialization of services for Lambda warm starts."""
    global _user_service, _asset_service, _verification_service, _audit_ledger, _paseto_adapter, _master_key, _initialized
    
    if _initialized:
        return
    
    # Check if running in local test mode
    is_local = os.getenv('LOCAL_TEST', 'false').lower() == 'true'
    
    if is_local:
        # Use in-memory adapters for local testing
        user_repo = InMemoryUserRepository()
        asset_repo = InMemoryAssetRepository()
        audit_ledger = InMemoryAuditLedger()
    else:
        # Use DynamoDB adapters for production
        from backend.adapters.dynamodb_repo import (
            DynamoDbUserRepository, DynamoDbAssetRepository, DynamoDbAuditLedger
        )
        user_repo = DynamoDbUserRepository()
        asset_repo = DynamoDbAssetRepository()
        audit_ledger = DynamoDbAuditLedger()
    
    # Initialize services
    _audit_ledger = audit_ledger
    _user_service = UserService(user_repo, audit_ledger)
    _asset_service = AssetService(asset_repo, user_repo, audit_ledger)
    _verification_service = VerificationService(audit_ledger)
    _paseto_adapter = PASETOAdapter()
    
    # Load master key from environment (in production, use Secrets Manager)
    master_key_env = os.getenv('PASETO_MASTER_KEY')
    if master_key_env:
        _master_key = bytes.fromhex(master_key_env)
    else:
        # Generate or use default for local testing
        _master_key = os.urandom(32)
    
    _initialized = True


def _get_caller_from_claims(claims: Dict[str, Any]) -> Optional[User]:
    """Extract caller identity from JWT claims and cross-reference with database."""
    if not claims:
        return None
    
    try:
        user_id = claims.get('sub') or claims.get('cognito:username') or claims.get('username')
        email = claims.get('email') or claims.get('cognito:email')
        
        # 1. Try to find user in database via cognito username / sub / email
        if _user_service and user_id:
            try:
                db_user = _user_service.get_user_by_cognito(user_id)
                if not db_user and email:
                    all_users = _user_service.list_users()
                    for u in all_users:
                        if (u.email and u.email.lower() == email.lower()) or u.cognitoUsername == user_id or u.userId == user_id:
                            db_user = u
                            break
                if db_user:
                    return db_user
            except Exception as e:
                print(f"Error looking up user in DB: {e}")
        
        role_str = claims.get('custom:role')
        if not role_str:
            role_str = 'Admin' if (email and 'admin' in email.lower()) else 'User'
            
        clearance_str = claims.get('custom:clearanceLevel')
        if not clearance_str:
            clearance_str = 'TOP_SECRET' if role_str == 'Admin' else 'UNCLASSIFIED'
            
        unit_str = claims.get('custom:unit', 'BEL_LABS' if role_str == 'Admin' else 'ARMY')
        compartments_str = claims.get('custom:compartments', '')
        
        if not user_id:
            return None
        
        compartments = [c.strip() for c in compartments_str.split(',') if c.strip()] if compartments_str else []
        
        return User(
            userId=user_id,
            name=claims.get('name', email or user_id),
            email=email or f"{user_id}@bel.defence.in",
            role=UserRole(role_str),
            clearanceLevel=ClearanceLevel[clearance_str],
            unit=MilitaryUnit(unit_str),
            compartments=compartments,
            cognitoUsername=claims.get('cognito:username', user_id),
        )
    except Exception as e:
        print(f"Error parsing caller from claims: {e}")
        return None


def _match_route(method: str, path: str) -> Optional[Dict[str, Any]]:
    """Match HTTP method and path to route configuration."""
    path_params = {}
    
    for route_pattern, config in ROUTES.items():
        route_method, route_path = route_pattern.split(' ', 1)
        
        if route_method != method:
            continue
            
        # Check for path parameter matches
        if '{' in route_path:
            pattern = route_path.replace('{id}', '([^/]+)').replace('{asset_id}', '([^/]+)')
            pattern = '^' + pattern + '$'
            match = re.match(pattern, path)
            if match:
                param_names = re.findall(r'\{([^}]+)\}', route_path)
                path_params = dict(zip(param_names, match.groups()))
                return {**config, 'path_params': path_params}
        elif route_path == path:
            return {**config, 'path_params': path_params}
    
    return None


# Route configuration table
ROUTES = {
    'POST /users': {
        'handler': '_create_user',
        'roles': ['Admin'],
    },
    'GET /users': {
        'handler': '_list_users',
        'roles': ['Admin', 'Manager'],
    },
    'POST /assets': {
        'handler': '_register_asset',
        'roles': ['Admin', 'Manager'],
    },
    'GET /assets': {
        'handler': '_list_assets',
        'roles': [],  # ABAC filtered in service
    },
    'GET /assets/{id}': {
        'handler': '_get_asset',
        'roles': [],  # ABAC checked in service
    },
    'PUT /assets/{id}/transfer': {
        'handler': '_transfer_custody',
        'roles': [],  # ABAC checked in service
    },
    'GET /audit': {
        'handler': '_get_audit',
        'roles': ['Admin', 'Manager', 'Auditor'],
    },
    'POST /verify': {
        'handler': '_verify_ledger',
        'roles': [],  # Public endpoint
    },
}


def _success_response(data: Any, status: int = 200, message: str = "Success") -> Dict[str, Any]:
    """Create standardized success response envelope."""
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Client-Version,X-Request-ID",
        },
        "body": json.dumps({"success": True, "message": message, "data": data})
    }


def _error_response(status: int, code: str, message: str) -> Dict[str, Any]:
    """Create standardized error response envelope."""
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Client-Version,X-Request-ID",
        },
        "body": json.dumps({"success": False, "message": message, "error": {"code": code, "message": message}})
    }


def _cors_response() -> Dict[str, Any]:
    """Handle CORS preflight requests."""
    return {
        "statusCode": 200,
        "headers": {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Client-Version,X-Request-ID",
            "Access-Control-Max-Age": "86400",
        },
        "body": ""
    }


def _handle_exception(e: Exception) -> Dict[str, Any]:
    """Map domain exceptions to HTTP status codes."""
    if isinstance(e, PermissionError):
        return _error_response(403, "CLEARANCE_DENIED", str(e))
    elif isinstance(e, ValueError):
        return _error_response(400, "VALIDATION_ERROR", str(e))
    return _error_response(500, "INTERNAL_ERROR", "Internal server error")


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    API Gateway v2 HTTP API Lambda proxy handler.
    
    Payload format version 2.0:
    - routeKey: "POST /users"
    - rawPath: "/users"
    - requestContext.authorizer.jwt.claims: JWT claims
    - body: JSON string
    - pathParameters: dict
    """
    try:
        _init_services()
        
        # Extract route info
        route_key = event.get('routeKey', '')
        http_method = event.get('requestContext', {}).get('http', {}).get('method', '')
        path = event.get('rawPath', '')
        
        # CORS preflight
        if http_method == 'OPTIONS':
            return _cors_response()
        
        # Extract caller identity from JWT authorizer
        claims = event.get('requestContext', {}).get('authorizer', {}).get('jwt', {}).get('claims', {})
        caller = _get_caller_from_claims(claims) if claims else None
        
        # Parse request body
        body = {}
        if event.get('body'):
            try:
                body = json.loads(event['body'])
            except json.JSONDecodeError:
                return _error_response(400, "VALIDATION_ERROR", "Invalid JSON body")
        
        # Parse path parameters
        path_params = event.get('pathParameters', {}) or {}
        
        # Match route
        route = _match_route(http_method, path)
        if not route:
            return _error_response(404, "NOT_FOUND", f"Route {http_method} {path} not found")
        
        # Role-based authorization check
        required_roles = route.get('roles', [])
        if required_roles and caller:
            if caller.role.value not in required_roles:
                return _error_response(403, "FORBIDDEN", f"Required roles: {required_roles}")
        elif required_roles and not caller:
            return _error_response(401, "UNAUTHORIZED", "Authentication required")
        
        # Merge path params into body for handlers
        merged_body = {**body, **route.get('path_params', {})}
        
        # Dispatch to handler
        handler_name = route['handler']
        handler = globals()[handler_name]
        result = handler(caller, merged_body)
        
        return _success_response(result, 201 if http_method == 'POST' else 200)
        
    except PermissionError as e:
        return _error_response(403, "CLEARANCE_DENIED", str(e))
    except ValueError as e:
        return _error_response(400, "VALIDATION_ERROR", str(e))
    except KeyError as e:
        return _error_response(404, "NOT_FOUND", f"Resource not found: {e}")
    except Exception as e:
        # Log error (in production, use structured logging)
        print(f"Lambda error: {type(e).__name__}: {e}")
        return _error_response(500, "INTERNAL_ERROR", "Internal server error")


# ──────────────────────────────────────────────────────────────
# Route Handlers
# ──────────────────────────────────────────────────────────────

def _create_user(caller: Optional[User], body: Dict[str, Any]) -> Dict[str, Any]:
    """POST /users - Create new user (Admin only)."""
    if not caller:
        raise PermissionError("Authentication required")
    user = _user_service.create_user(caller, body)
    return {
        "userId": user.userId,
        "name": user.name,
        "email": user.email,
        "role": user.role.value,
        "clearanceLevel": user.clearanceLevel.name,
        "unit": user.unit.value,
        "compartments": user.compartments,
    }


def _list_users(caller: Optional[User], body: Dict[str, Any]) -> Dict[str, Any]:
    """GET /users - List all users (Admin/Manager only)."""
    users = _user_service.list_users()
    return {
        "users": [
            {
                "userId": u.userId,
                "name": u.name,
                "email": u.email,
                "role": u.role.value,
                "clearanceLevel": u.clearanceLevel.name,
                "unit": u.unit.value,
                "compartments": u.compartments,
                "status": u.status,
            }
            for u in users
        ],
        "count": len(users),
    }


def _register_asset(caller: Optional[User], body: Dict[str, Any]) -> Dict[str, Any]:
    """POST /assets - Register new asset (Admin/Manager only)."""
    if not caller:
        raise PermissionError("Authentication required")
    asset = _asset_service.register_asset(caller, body)
    return {
        "assetId": asset.assetId,
        "name": asset.name,
        "assetType": asset.assetType,
        "classification": asset.classification.name,
        "unit": asset.unit.value,
        "compartment": asset.compartment,
        "custodianId": asset.custodianId,
        "state": asset.state.value,
        "contentHash": asset.contentHash,
    }


def _list_assets(caller: Optional[User], body: Dict[str, Any]) -> Dict[str, Any]:
    """GET /assets - List assets (ABAC filtered)."""
    if not caller:
        raise PermissionError("Authentication required")
    assets = _asset_service.list_assets(caller)
    return {
        "assets": [
            {
                "assetId": a.assetId,
                "name": a.name,
                "assetType": a.assetType,
                "classification": a.classification.name,
                "unit": a.unit.value,
                "compartment": a.compartment,
                "custodianId": a.custodianId,
                "state": a.state.value,
            }
            for a in assets
        ],
        "count": len(assets),
    }


def _get_asset(caller: Optional[User], body: Dict[str, Any]) -> Dict[str, Any]:
    """GET /assets/{id} - Get asset by ID (ABAC checked)."""
    if not caller:
        raise PermissionError("Authentication required")
    asset_id = body.get('id')
    if not asset_id:
        raise ValueError("Asset ID required")
    asset = _asset_service.get_asset(caller, asset_id)
    return {
        "assetId": asset.assetId,
        "name": asset.name,
        "assetType": asset.assetType,
        "classification": asset.classification.name,
        "unit": asset.unit.value,
        "compartment": asset.compartment,
        "custodianId": asset.custodianId,
        "state": asset.state.value,
        "contentHash": asset.contentHash,
        "custodyChain": asset.custodyChain,
        "metadata": asset.metadata,
    }


def _transfer_custody(caller: Optional[User], body: Dict[str, Any]) -> Dict[str, Any]:
    """PUT /assets/{id}/transfer - Transfer asset custody."""
    if not caller:
        raise PermissionError("Authentication required")
    
    asset_id = body.get('id')
    new_custodian_id = body.get('newCustodianId')
    transfer_ticket = body.get('transferTicket')
    
    if not asset_id or not new_custodian_id:
        raise ValueError("Asset ID and new custodian ID required")
    
    asset = _asset_service.transfer_custody(
        caller, asset_id, new_custodian_id,
        transfer_ticket=transfer_ticket,
        key=_master_key
    )
    
    return {
        "assetId": asset.assetId,
        "name": asset.name,
        "custodianId": asset.custodianId,
        "state": asset.state.value,
        "custodyChain": asset.custodyChain,
    }


def _get_audit(caller: Optional[User], body: Dict[str, Any]) -> Dict[str, Any]:
    """GET /audit - Get audit ledger (Admin/Manager/Auditor only)."""
    result = _verification_service.verify_ledger()
    records = _audit_ledger.get_all() if _audit_ledger else []
    events = [
        {
            "eventId": r.eventId,
            "timestamp": r.timestamp,
            "actorId": r.actorId,
            "actorRole": r.actorRole,
            "action": r.action,
            "resourceType": r.resourceType,
            "resourceId": r.resourceId,
            "prevHash": r.prevHash,
            "currentHash": r.currentHash,
            "payloadHash": r.payloadHash,
            "details": r.details,
        }
        for r in records
    ]
    return {
        **result,
        "events": events,
    }


def _verify_ledger(caller: Optional[User], body: Dict[str, Any]) -> Dict[str, Any]:
    """POST /verify - Verify ledger integrity."""
    result = _verification_service.verify_ledger()
    return result